#pragma once
#include <glm/glm.hpp>
class Material {
public:
  virtual ~Material();
protected:
  Material();
};
